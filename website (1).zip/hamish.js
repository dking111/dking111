const images = document.querySelector(".images");
const slideshows = document.querySelectorAll('[data-component="slideshow"]');

function initSlideShow(slideshow) {
	var slides = document.querySelectorAll(`#${slideshow.id} [role="list"] .slide`);

	var index = 0, time = 4000;
	slides[index].classList.add('active');

	setInterval( () => {
		slides[index].classList.remove('active');
		
		index++;
		if (index === slides.length) index = 0;

		slides[index].classList.add('active');

	}, time);
}


const processImages = data => {
  console.log(data);
  data.forEach(i => {
    const base = document.createElement("div");
    base.className = "slide";
    const img = document.createElement("img");
    img.src = i.url;

    base.append(img);
    images.append(base);
  })

  slideshows.forEach(s => initSlideShow(s));
}

const data = fetch("https://mish-images-api.vercel.app/api/images", { 
  method: "GET",
  headers: {
    "Content-Type": "application/json",
  }
})
  .then(r => r.json())
  .then(processImages);